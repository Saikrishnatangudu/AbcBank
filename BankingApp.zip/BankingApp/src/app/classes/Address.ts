export class Address{
	
	street : string;
    city  : string;
	state : string;
	pincode : string ;
	

}