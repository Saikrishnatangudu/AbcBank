export class Transactions{
    id:number;
    transactionDate:Date;
    transactionAmmount:number;
    BalanceOnDate:number;
    fromAccNo:number;
    toAccNo:number;
    transactionId:number;
    transactionRemarks:string;


}