import { User } from "./User";

export class Account{

        AccNo:number;
        balance:number;
        AccType:string;

}